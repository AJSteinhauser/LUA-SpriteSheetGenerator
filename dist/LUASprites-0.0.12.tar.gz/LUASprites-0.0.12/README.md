
# LUA Sprites
##### Generate sprite sheets and formatting code at the same time
---

Installation:

> $ pip3 install LUASprites

Usage: 
> $ luasprite spritefolder

Where ```spritefolder``` is the directory containing the images you want combined on the sprite sheet


The spritesheet will be stored in a new directory named output(number) parented to the ```spritefolder``` given as a command line argument. For more information regarding this tool, please refer to the Roblox documentation: [DEVFORUM LINK HERE]